# TriciTaxi Cuba — proyecto inicial

Proyecto Flutter para Android, preparado para compilar una APK de prueba mediante GitHub Actions.

## Incluye
- Interfaz inicial con perfiles de pasajero, conductor y administrador.
- Solicitudes y reservas de demostración.
- Campo para precio manual.
- Workflow para compilar APK de depuración en la nube.

## Limitación actual
Esta versión es una demostración local: no transmite solicitudes a otros teléfonos y no incluye backend, GPS en tiempo real, cuentas ni notificaciones. No debe utilizarse para operar un servicio comercial hasta implementar y probar esas partes.

## Cómo obtener la APK desde un teléfono
1. Crea un repositorio GitHub llamado `tricitaxi-cuba`.
2. Sube todos los archivos y carpetas de este ZIP a la raíz del repositorio, conservando la ruta `.github/workflows/build-apk.yml`.
3. En GitHub abre **Actions** y habilita los workflows si se solicita.
4. Ejecuta **Build Android APK** mediante **Run workflow** o espera a que termine la ejecución del push a `main`.
5. Abre la ejecución exitosa y descarga el artefacto `tricitaxi-cuba-apk`.
6. Descomprime el ZIP del artefacto y abre `app-debug.apk` en el Samsung para instalarlo. Android podría pedir permiso para instalar desde el navegador o gestor de archivos.

La APK de depuración es para pruebas; no es una versión firmada de lanzamiento.
