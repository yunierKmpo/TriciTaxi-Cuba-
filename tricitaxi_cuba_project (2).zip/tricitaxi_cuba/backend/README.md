# Backend pendiente para TriciTaxi Cuba

La app incluida es una demostración local. Para que pasajeros y conductores en distintos teléfonos compartan viajes, debe configurarse un backend seguro (por ejemplo, Supabase o un servidor propio), autenticación, roles, políticas de acceso, estados de viaje y notificaciones.

No almacenes claves secretas dentro de la APK. Antes de operar con clientes reales, configura controles de acceso, protección de datos y prueba conectividad desde las redes que se utilizarán en Cuba.
