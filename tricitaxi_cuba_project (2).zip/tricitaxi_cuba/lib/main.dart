import 'package:flutter/material.dart';

void main() => runApp(const TriciTaxiApp());

class TriciTaxiApp extends StatelessWidget {
  const TriciTaxiApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'TriciTaxi Cuba',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF147D55)),
          useMaterial3: true,
        ),
        home: const HomePage(),
      );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String role = 'Pasajero';
  String kind = 'Ahora';
  final pickup = TextEditingController();
  final destination = TextEditingController();
  final price = TextEditingController();
  final List<Map<String, String>> trips = [];

  @override
  void dispose() {
    pickup.dispose();
    destination.dispose();
    price.dispose();
    super.dispose();
  }

  void message(String text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));

  void requestTrip() {
    if (pickup.text.trim().isEmpty || destination.text.trim().isEmpty) {
      message('Escribe el origen y el destino.');
      return;
    }
    setState(() => trips.insert(0, {
          'origin': pickup.text.trim(),
          'destination': destination.text.trim(),
          'price': price.text.trim().isEmpty ? 'A convenir' : price.text.trim(),
          'kind': kind,
        }));
    pickup.clear();
    destination.clear();
    price.clear();
    message('Solicitud de demostración creada en este teléfono. Aún no se comparte por internet.');
  }

  @override
  Widget build(BuildContext context) {
    final passenger = role == 'Pasajero';
    final driver = role == 'Conductor';
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF147D55),
        foregroundColor: Colors.white,
        title: const Row(children: [Icon(Icons.local_taxi), SizedBox(width: 8), Text('TriciTaxi Cuba')]),
        actions: [PopupMenuButton<String>(
          onSelected: (value) => setState(() => role = value),
          itemBuilder: (_) => const [
            PopupMenuItem(value: 'Pasajero', child: Text('Modo pasajero')),
            PopupMenuItem(value: 'Conductor', child: Text('Modo conductor')),
            PopupMenuItem(value: 'Administrador', child: Text('Modo administrador')),
          ],
        )],
      ),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(color: const Color(0xFF147D55), borderRadius: BorderRadius.circular(20)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(role.toUpperCase(), style: const TextStyle(color: Colors.white70, letterSpacing: 1.5)),
            const SizedBox(height: 8),
            Text(passenger ? 'Muévete por tu ciudad.' : driver ? 'Tus viajes, a un toque.' : 'Administra tu flota.',
                style: const TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('Transporte en triciclos eléctricos · Pago en efectivo', style: TextStyle(color: Colors.white)),
          ]),
        ),
        const SizedBox(height: 18),
        if (passenger) ...[
          const Text('Solicitar un triciclo', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          TextField(controller: pickup, decoration: const InputDecoration(labelText: 'Punto de recogida', hintText: 'Ej. Parque central', prefixIcon: Icon(Icons.trip_origin), border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: destination, decoration: const InputDecoration(labelText: 'Destino', hintText: 'Ej. Hospital', prefixIcon: Icon(Icons.location_on_outlined), border: OutlineInputBorder())),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(value: kind, decoration: const InputDecoration(labelText: 'Servicio', border: OutlineInputBorder()), items: const [DropdownMenuItem(value: 'Ahora', child: Text('Solicitar ahora')), DropdownMenuItem(value: 'Reserva', child: Text('Reservar para después'))], onChanged: (value) => setState(() => kind = value ?? 'Ahora')),
          const SizedBox(height: 12),
          TextField(controller: price, decoration: const InputDecoration(labelText: 'Precio (opcional)', hintText: 'A convenir con el conductor', prefixIcon: Icon(Icons.payments_outlined), border: OutlineInputBorder())),
          const SizedBox(height: 14),
          SizedBox(height: 52, child: FilledButton.icon(onPressed: requestTrip, icon: const Icon(Icons.local_taxi), label: const Text('Solicitar triciclo'))),
        ],
        if (driver) ...[
          const Text('Panel del conductor', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Card(child: ListTile(leading: Icon(Icons.wifi), title: Text('Disponibilidad'), subtitle: Text('Se conectará al habilitar el servidor.'))),
          const Card(child: ListTile(leading: Icon(Icons.route), title: Text('Solicitudes'), subtitle: Text('Las solicitudes reales aparecerán al configurar el backend.'))),
        ],
        if (!passenger && !driver) ...[
          const Text('Panel de administración', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Card(child: ListTile(leading: Icon(Icons.people), title: Text('Conductores'), subtitle: Text('Registro y aprobación pendientes de conectar al servidor.'))),
          const Card(child: ListTile(leading: Icon(Icons.directions_car), title: Text('Flota de triciclos'), subtitle: Text('Vehículos, capacidad y estado.'))),
          const Card(child: ListTile(leading: Icon(Icons.receipt_long), title: Text('Viajes y tarifas'), subtitle: Text('Gestión de reservas y precios.'))),
        ],
        const SizedBox(height: 18),
        Row(children: [const Expanded(child: Text('Solicitudes de demostración', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))), Chip(label: Text('${trips.length}'))]),
        if (trips.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('Todavía no hay solicitudes. Puedes crear una para probar la pantalla.'))),
        ...trips.map((trip) => Card(child: ListTile(leading: const CircleAvatar(child: Icon(Icons.local_taxi)), title: Text('${trip['origin']} → ${trip['destination']}'), subtitle: Text(trip['kind'] ?? 'Ahora'), trailing: Text(trip['price'] ?? 'A convenir')))),
        const SizedBox(height: 14),
        const Text('Versión inicial de demostración: los viajes no se comparten entre teléfonos. Antes de usarla con clientes hay que conectar un servidor seguro, inicio de sesión, GPS y notificaciones.', style: TextStyle(fontSize: 12, color: Colors.black54)),
      ]),
    );
  }
}
